console.log('Hello, world!');

let cvs = document.getElementById('canvas');
let ctx = cvs.getContext('2d');

let bird_url = document.querySelector(".hid").textContent;if(bird_url == '') 
bird_url = 'img/bird.png';
console.log(bird_url);


let bird = new Image();
/*let bird2 = new Image();
let bird3 = new Image();
let bird4 = new Image();
let bird5 = new Image();*/
let background = new Image();
let background2 = new Image();
let background3 = new Image();
let background4 = new Image();
let background5 = new Image();
let wallUp = new Image();
let wallUnder = new Image(); 
let start = new Image();
let gameOver = new Image();
let bord = new Image();
let bronz = new Image();
let sereb = new Image();
let gold = new Image();
let plat = new Image();
let change = new Image();
let levl = new Image();

levl.src = "/img/levl.png";
change.src = "img/change (2).png";
bronz.src = "img/bronza.png";
sereb.src = "img/serebro.png";
gold.src = "img/gold.png";
plat.src = "img/platina.png";
bord.src = "img/border.png";
bird.src = `${bird_url}`;
console.log(bird);
/*bird2.src = "img/bird2.png"
bird3.src = "img/bird3.png";
bird4.src = "img/bird4.png";
bird5.src = "img/bird5.png";*/
start.src = "img/start.png";
gameOver.src = "img/end.png";
wallUp.src = "img/wall.png";
wallUnder.src = "img/wall2.png";
background5.src = "img/bg5.png";
background4.src = "img/bg4.png";
background3.src = "img/bg3.png";
background2.src = "img/bg2.png";
background.src = "img/bg.png";

let char = new Audio();
let die = new Audio();
let flap = new Audio();
let point = new Audio();
let shoot = new Audio();


char.src = "audio/change.mp3";
die.src = "audio/die.wav";
flap.src = "audio/fly.wav";
point.src = "audio/point.wav";
shoot.src = "audio/hit.wav"



let xPos = 10;
let yPos = 185;
let gravitation = 1.7;


let state = 0;
let space = 120;
let score = 0;
let best = 0;
let speed = 1;
let polet = 45;
let pers = 0;
let fon = 0;

let count = 0;

let wall = [];

 wall[0] = {
     x: 340,
     y: Math.floor(Math.random() * (wallUp.height )) - wallUp.height
 }




function draw(){
    switch(fon){
        case 0:   ctx.drawImage(background, 0, 0);
        break;
        case 1:   ctx.drawImage(background2, 0, 0);
        break;
        case 2:   ctx.drawImage(background4, 0, 0);
        break;
        case 3:   ctx.drawImage(background3, 0, 0);
        break;
        case 4:   ctx.drawImage(background5, 0, 0, 320, 480);
        break;
    }

    if(state == 0) ctx.drawImage(start, 72, 140);

    if(state == 1){
        /*switch(pers){
            case 0:
            ctx.drawImage(bird, xPos, yPos);
            break;
            case 1: ctx.drawImage(bird2, xPos, yPos, 30, 30);
            break;
            case 2: ctx.drawImage(bird3, xPos, yPos, 30, 30);
            break;
            case 3: ctx.drawImage(bird4, xPos, yPos, 30, 30);
            break;
            case 4: ctx.drawImage(bird5, xPos, yPos, 30, 30);
            break;
        }*/
        
        ctx.drawImage(bird, xPos, yPos);

        yPos+=gravitation;
        
        for(i = 0; i < wall.length; i++, count++){
            ctx.drawImage(wallUp, wall[i].x, wall[i].y);
            ctx.drawImage(wallUnder, wall[i].x, wall[i].y + wallUp.height + space);

            if(wall[i].x >= 99.5 && wall[i].x < 100.5 ){
                wall.push({
                    x: cvs.width,
                    y: Math.floor(Math.random() * (wallUp.height - 15)) - wallUp.height + 15
                })
            }
            
            
            
            wall[i].x-=speed;

            if((xPos + 40 >= wall[i].x)
            && (xPos + 10 <=  wall[i].x + wallUp.width)
            && ((yPos + 15 <=  wall[i].y +  wallUp.height)
            || (yPos + 35 >=  wall[i].y + wallUp.height + space)) || yPos + 50 >= cvs.height - 62){
                    if(best < score){
                        best = score; 
                    }
                    state = 2;
                    wall.shift();
                    wall[0] = {
                        x: 340,
                        y: Math.floor(Math.random() * (wallUp.height - 15)) - wallUp.height + 15
                    } 
                    shoot.play();
                    setTimeout(() => die.play(), 500);
            }

            if(wall[i].x >= 6.2 && wall[i].x < 7.5){
                score++;
                point.play();
                break;
            }
             

         

                if(i == 5 && score < i + 1){
                    ctx.drawImage(change, wall[i].x - 10, wall[i].y + wallUp.height + 18, 75, 75);
                   
                    if(wall[i].x >= 8.5 && wall[i].x <9.5){
                        fon++;
                        pers++;
                        char.play();
                        speed = 1.1;
                        gravitation = 1.8;
                        space = 110;
                    }
                }

                if(i == 10 && score < i + 1){
                    ctx.drawImage(change, wall[i].x - 10, wall[i].y + wallUp.height + 18, 75, 75);
                    if(wall[i].x >= 8.5 && wall[i].x <9.5){
                        fon++;
                        pers++;
                        char.play();
                        speed = 1,2;
                        gravitation = 1.9;
                        space = 105;
                    }
                }
                
                if(i == 15 && score < i + 1){
                    ctx.drawImage(change, wall[i].x - 10, wall[i].y + wallUp.height + 18, 75, 75);
                    if(wall[i].x >= 8.5 && wall[i].x <9.5){
                        polet = 50;
                        fon++;
                        pers++;
                        char.play();
                        speed = 1.3;
                        gravitation = 2;
                        space = 100;
                    }
                }

                if(i == 20 && score < i+1){
                    ctx.drawImage(change, wall[i].x - 10, wall[i].y + wallUp.height + 18, 75, 75);
                    if(wall[i].x >= 8.5 && wall[i].x <10.3){
                        fon++;
                        pers++;
                        char.play();
                        speed = 1.4;
                        gravitation = 2.1;
                        space = 90;
                    }
                }

                if(score == 6 && i <= 6){
                    ctx.drawImage(levl, wall[i].x - 130, 10, 100, 50);
                }
                if(score == 11 && i <= 11){
                    ctx.drawImage(levl, wall[i].x - 130, 10, 100, 50);
                }
                if(score == 16 && i <= 16){
                    ctx.drawImage(levl, wall[i].x - 130, 10, 100, 50);
                }
                if(score == 21 && i <= 21){
                    ctx.drawImage(levl, wall[i].x - 130, 10, 100, 50);
                }

               

            }
            
    }

    if(state == 2){
        ctx.drawImage(gameOver, 47, 140);

        ctx.fillStyle = "#000";
        ctx.strokeStyle = "#fff";
        ctx.font = "20px Teko";
        if(score < 10){
            ctx.fillText(score, 232, 236);
        }
        else ctx.fillText(score, 222, 236);

        ctx.fillStyle = "#000";
        ctx.strokeStyle = "#fff";
        ctx.font = "20px Teko";
        if(best < 10){
            ctx.fillText(best, 232, 276);
        }
        else ctx.fillText(best, 222, 276);

        if(score >= 5){
            ctx.drawImage(bronz, 72, 226);
        }
        if(score >= 10){
            ctx.drawImage(sereb, 72, 226);
        }
        if(score >= 15){
            ctx.drawImage(gold, 72, 226);
        }
        if(score >= 20){
            ctx.drawImage(plat, 72, 226);
        }
        
    }

    

    ctx.fillStyle = "#84cc52";
    ctx.fillRect(0, 405, cvs.width, 130);

    ctx.fillStyle = "#00b300";
    ctx.fillRect(0, 405, cvs.width, 5);

    ctx.drawImage(bord, 121, 402);
    ctx.fillStyle = "#fff";
    ctx.strokeStyle = "#000";
    ctx.font = "40px Teko";
    if(score < 10){
        ctx.fillText(score, 150, 455);
    }
    else
    ctx.fillText(score, 138, 455);

    
    requestAnimationFrame(draw);
}

background.onload = draw;




cvs.addEventListener("click", function(){
    if(state == 0){
        state = 1;
    } 
    else if(state == 2){
        let score_send = document.querySelector('input[name="send"]');
        score_send.value = `${score}`;
        score_send.click();
        fon = 0;
        polet = 45;
        speed = 1;
        space = 120;
        gravitation = 1.7;
        wall.length = 1;
        pers = 0;
        score = 0;
        xPos = 10;
        yPos = 185;
        state = 0;
    }
    if(state == 1){
        fly();
    }
})

function fly(){
    yPos-=polet;
    flap.play();
}