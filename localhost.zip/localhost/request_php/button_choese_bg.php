<?php
$value = $_POST['myActionName'];
setcookie('bg', $value, time() + 3600, "/");
header('Location: /shop/market_background.php');
?>