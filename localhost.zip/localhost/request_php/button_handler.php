<?php
$value = $_POST['myActionName'];
switch($value){
    case 0: header('Location: /game.php'); break;
    case 1: header('Location: /shop/market_menu.php'); break;
    case 2: header('Location: /results/result_menu.php'); break;
    case 3: header('Location: /index.php'); break;
}
    
?>