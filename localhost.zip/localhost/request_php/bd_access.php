<?php
    $mysql = new mysqli('127.0.0.1', 'root', '', 'info_bd');
    if($mysql == false){
        echo mysqli_connect_error();
        exit();
    }
?>