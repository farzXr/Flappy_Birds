<?php
$value = $_POST['myActionName'];
switch($value){
    case 0: header('Location: /results/result.php'); break;
    case 1: header('Location: /results/global_record.php'); break;
    case 2: header('Location: /main/menu.php'); break;
}
    
?>