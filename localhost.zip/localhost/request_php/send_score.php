<?php
        $score = $_POST['send'];
        echo $score;
        include ('bd_access.php');
        $login = $_COOKIE['user'];
        $result = $mysql->query("SELECT id FROM user WHERE login = '$login'");
        $id = $result->fetch_assoc();
        $id_send = $id['id'];
        echo $score;
        $mysql->query("INSERT INTO result (id, res, dating) VALUES('$id_send', '$score', NOW())");
        header('Location: /game.php');
    ?>