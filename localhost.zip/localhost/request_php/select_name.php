<?php
    include('bd_access.php');
    $login = $_COOKIE['user'];
    $result = $mysql->query("SELECT name FROM user WHERE login = '$login'");
    $name = $result->fetch_assoc();
    echo $name['name'];
/*<h1><?php include('/request_php/select_name.php') ?></h1> */
?>