<?php
    include('bd_access.php');
    $login = $_COOKIE['user'];
    $result_id = $mysql->query("SELECT id FROM user WHERE login = '$login'");
    $id_res = $result_id->fetch_assoc();
    $id= $id_res['id'];
    $result = $mysql->query("SELECT dating FROM result WHERE id = '$id' ORDER BY res DESC");
    for($i = 0; $i < $_COOKIE['point']; $i++){
        $res = $result->fetch_assoc();
    }
    $res_print = $res['dating'];
    if($res_print == '') echo '-';
    else
    echo $res_print;
?>