<?php
$value = $_POST['myActionName'];
$_COOKIE[bird] = $value;
header('Location: /shop/market_character.php');
?>