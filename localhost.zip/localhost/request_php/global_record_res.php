<?php
    include('bd_access.php');
    $result = $mysql->query("SELECT id, res FROM result ORDER BY res DESC");
    for($i = 0; $i < $_COOKIE['point']; $i++){
        $res = $result->fetch_assoc();
    }
    $res_print = $res['res'];
    if($res_print == '') echo '-';
    else
    echo $res_print;
?>