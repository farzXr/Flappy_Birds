<?php
    include('bd_access.php');
    $result = $mysql->query("SELECT id, res FROM result ORDER BY res DESC");
    for($i = 0; $i < $_COOKIE['point']; $i++){
        $res = $result->fetch_assoc();
    }
    $res_id = $res['id'];
    $result_id = $mysql->query("SELECT name FROM user WHERE id = '$res_id'");
    $name = $result_id->fetch_assoc();
    $name_print = $name['name'];
    if($name_print == '') echo '-';
    else
    echo $name_print;
?>