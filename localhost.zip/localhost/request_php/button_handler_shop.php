<?php
$value = $_POST['myActionName'];
switch($value){
    case 0: header('Location: /shop/market_background.php'); break;
    case 1: header('Location: /shop/market_character.php'); break;
    case 2: header('Location: /main/menu.php'); break;
}
    
?>