<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="game.css">
    <title>Flappy anything</title>
    <style>        
        canvas{
            border: 1px solid #000;
            display: block;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <main>
        <header>
            <?php 
                echo 'Игрок: ';
                include ('request_php/select_name.php');
            ?>
        </header>
        <canvas id="canvas" width="320" height="480"></canvas>
    <footer>
        <form action="request_php/exit_main_menu.php", method = "post">
            <div id="home" class="div"><button name="myActionName" class="p" type="submit">Выйти</button>
            </div>
        </form>  
    </footer>
    </main>
    <div class="hid" style = "display: none;"><?php echo $_COOKIE['bird']?></div>
    <form action="request_php/send_score.php", method = "post">
        <input name = "send" type="submit" style = "display: none;">
    </form>
    <script src="script/script.js">
    </script>
</body>
</html>