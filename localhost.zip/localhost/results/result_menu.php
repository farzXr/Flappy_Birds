<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="menu.css">
    <title>Document</title>
</head>
<body>
    <div class="main" style = "background: url('<?php if($_COOKIE['bg'] != '')echo $_COOKIE['bg']; else echo "/img/bg.png"; ?>')">
            <header>
                <?php 
                    echo 'Игрок: ';
                    include ('../request_php/select_name.php');
                ?>
            </header>
        <section class="stage">
            <form action="/request_php/menu_result.php", method = "post">
                <div id="home" class="div"><button name="myActionName" class="p" type="submit" value="0">Результаты</button>
                </div>
                <div class="div" id="about"><button name="myActionName" class="p" type="submit" value="1">ТОП</button>
                </div>
                <div class="div" id="contact"><button name="myActionName" class="p" type="submit" value="2">Выйти</button>
                </div>
            </form>  
        </section>
    </div>
</body>
</html>