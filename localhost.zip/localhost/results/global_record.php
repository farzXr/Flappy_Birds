<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="global_record.css">
    <style>
        .ol-days > #num_1::before {
            <?php $_COOKIE['point'] = '1'; ?>
            content: '<?php include ("../request_php/global_record_res.php");?>';
        }
        .ol-days > #num_2::before {
            <?php $_COOKIE['point'] = '2'; ?>
	        content: '<?php include("../request_php/global_record_res.php");?>';
        }
        .ol-days > #num_3::before {
            <?php $_COOKIE['point'] = '3'; ?>
	        content: '<?php include("../request_php/global_record_res.php");?>';
        }
        .ol-days > #num_4::before {
            <?php $_COOKIE['point'] = '4'; ?>
	        content: '<?php include("../request_php/global_record_res.php");?>';
        }
        .ol-days > #num_5::before {
            <?php $_COOKIE['point'] = '5'; ?>
	        content: '<?php include("../request_php/global_record_res.php");?>';
        }
        .ol-days > #num_6::before {
            <?php $_COOKIE['point'] = '6'; ?>
	        content: '<?php include("../request_php/global_record_res.php");?>';
        }
    </style>
    <title>Document</title>
</head>
<body>
    <div class="main" style = "background: url('<?php if($_COOKIE['bg'] != '')echo $_COOKIE['bg']; else echo "/img/bg.png"; ?>')">
            <header>
                <?php 
                    echo 'Игрок: ';
                    include ('../request_php/select_name.php');
                ?>
            </header>
            <ol class="ol-days">
                <li class = "style_li" id = "num_1"><?php $_COOKIE['point'] = '1'; include ('../request_php/global_record_name.php');?></li>
                <li class = "style_li" id = "num_2"><?php $_COOKIE['point'] = '2'; include ('../request_php/global_record_name.php');?></li>
                <li class = "style_li" id = "num_3"><?php $_COOKIE['point'] = '3'; include ('../request_php/global_record_name.php');?></li>
                <li class = "style_li" id = "num_4"><?php $_COOKIE['point'] = '4'; include ('../request_php/global_record_name.php');?></li>
                <li class = "style_li" id = "num_5"><?php $_COOKIE['point'] = '5'; include ('../request_php/global_record_name.php');?></li>
                <li class = "style_li" id = "num_6"><?php $_COOKIE['point'] = '6'; include ('../request_php/global_record_name.php');?></li>
            </ol>
        <section class="stage">
            <form action="/request_php/exit_res_menu.php", method = "post">
                <div id="home" class="div"><button name="myActionName" class="p" type="submit" value="0">Выйти</button>
                </div>
            </form>  
        </section>
    </div>
</body>
</html>