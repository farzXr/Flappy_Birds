<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="dubl_s.css">
    <title>Flappy anything</title>
</head>
<body>
<div class="main">  	
		<input type="checkbox" id="chk" aria-hidden="true">
			<div class="signup">
				<form action = "/register/sing.php", method = "post">
					<label for="chk" aria-hidden="true">Sign up</label>
					<div class="hidden">Неккоректный пароль или логин такой уже существует</div>
					<input type="text" name="name" placeholder="User name" required="">
                    <input type="text" name="login" placeholder="Login" required="">
					<input type="password" name="pass" placeholder="Password" required="">
					<button type = "submit">Sign up</button>
				</form>
			</div>

			<div class="login">
				<form action = "/register/log.php", method = "post">
					<label for="chk" aria-hidden="true">Log in</label>
					<input type="text" name="login" placeholder="Login" required="">
					<input type="password" name="pass" placeholder="Password" required="">
					<button type = "submit">Log in</button>
				</form>
			</div>
	</div>
</body>
</html>