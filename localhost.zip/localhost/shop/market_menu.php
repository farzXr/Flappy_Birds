<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="market_menu.css">
    <title>Document</title>
</head>
<body>
    <div class="main" style = "background: url('<?php if($_COOKIE['bg'] != '')echo $_COOKIE['bg']; else echo "/img/bg.png"; ?>')">
            <header>
                <?php 
                    echo 'Игрок: ';
                    include ('../request_php/select_name.php');
                ?>
            </header>
        <section class="stage">
            <form action="/request_php/button_handler_shop.php", method = "post">
            <div class="div" id="about"><button name="myActionName" class="p" type="submit" value="1">Персонаж</button>
                </div>
                <div id="home" class="div"><button name="myActionName" class="p" type="submit" value="0">Фон</button>
                </div>
                <div class="div" id="gallery"><button name="myActionName" class="p" type="submit" value="2">Выйти</button>
                </div>
                </div>
            </form>  
        </section>
    </div>
</body>
</html>