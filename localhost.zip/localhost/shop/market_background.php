<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="market_background.css">
    <title>Document</title>
</head>
<body>
  <div class="conteiner1" style = "background: url('<?php if($_COOKIE['bg'] != '')echo $_COOKIE['bg']; else echo "/img/bg.png"; ?>')">
    <header>
      <?php 
        echo 'Игрок: ';
        include ('../request_php/select_name.php');
      ?>
    </header>
    <main>
<ul>
<form action="/request_php/button_choese_bg.php", method = "post">
  <li> <img src="/img/bg.png" alt="cut citrus fruits. " /><div class="but"> <button class="but2" name="myActionName" type = "submit" value = "/img/bg.png">Выбрать</button></div></li>
  <li> <img src="/img/bg2.png" alt="cut citrus fruits. " /><div class="but"> <button class="but2" name="myActionName" type = "submit" value = "/img/bg2.png">Выбрать</button></div></li>
  <li> <img src="/img/bg3.png" alt="cut citrus fruits. " /><div class="but"> <button class="but2" name="myActionName" type = "submit" value = "/img/bg3.png">Выбрать</button></div></li>
  <li> <img src="/img/bg4.png" alt="cut citrus fruits. " /><div class="but"> <button class="but2" name="myActionName" type = "submit" value = "/img/bg4.png">Выбрать</button></div></li>
  <li> <img src="/img/bg5.png" alt="cut citrus fruits. " /><div class="but"> <button class="but2" name="myActionName" type = "submit" value = "/img/bg5.png">Выбрать</button></div></li>
  </form>
</ul>
    </main>
  <footer>
      <form action="/request_php/but_hand_bg.php", method = "post">
        <div id="home" class="div"><button name="myActionName" class="p" type="submit">Выйти</button>
        </div>
       </form>  
  </footer>
  </div>
</body>
</html>