<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="market_character.css">
    <title>Document</title>
</head>
<body>
  <div class="conteiner1" style = "background: url('<?php if($_COOKIE['bg'] != '')echo $_COOKIE['bg']; else echo "/img/bg.png"; ?>')">
    <header>
      <?php 
        echo 'Игрок: ';
        include ('../request_php/select_name.php');
      ?>
    </header>
    <main>
<ul>
<form action="/request_php/button_choese_bird.php", method = "post">
  <li> <img src="/img/bird.png" alt="cut citrus fruits. " /><div class="but"> <button class="but2" name="myActionName" type = "submit" value = "img/bird.png">Выбрать</button></div></li>
  <li> <img src="/img/bird2.png" alt="cut citrus fruits. " /><div class="but"> <button class="but2" name="myActionName" type = "submit" value = "img/bird2.png">Выбрать</button></div></li>
  <li> <img src="/img/bird3.png" alt="cut citrus fruits. " /><div class="but"> <button class="but2" name="myActionName" type = "submit" value = "img/bird3.png">Выбрать</button></div></li>
  <li> <img src="/img/bird4.png" alt="cut citrus fruits. " /><div class="but"> <button class="but2" name="myActionName" type = "submit" value = "img/bird4.png">Выбрать</button></div></li>
  <li> <img src="/img/bird5.png" alt="cut citrus fruits. " /><div class="but"> <button class="but2" name="myActionName" type = "submit" value = "img/bird5.png">Выбрать</button></div></li>
  </form>
</ul>
    </main>
  <footer>
      <form action="/request_php/but_hand_bg.php", method = "post">
        <div id="home" class="div"><button name="myActionName" class="p" type="submit">Выйти</button>
        </div>
       </form>  
  </footer>
  </div>
</body>
</html>