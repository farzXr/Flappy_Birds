<?php
    setcookie('answ', '1', time() + 3600, "/");

    $name = filter_var(trim($_POST['name']), FILTER_SANITIZE_STRING);
    $login = filter_var(trim($_POST['login']), FILTER_SANITIZE_STRING);
    $password = filter_var(trim($_POST['pass']), FILTER_SANITIZE_STRING);

    if(mb_strlen($name) < 2 || mb_strlen($name) > 15){
        $_COOKIE['answ'] = '0';
        header('Location: /index_dubl/index_dubl_s.php');
    }

    if(mb_strlen($login) < 5 || mb_strlen($login) > 25){
        $_COOKIE['answ'] = '0';
        header('Location: /index_dubl/index_dubl_s.php');
    }


    $mysql = new mysqli('127.0.0.1', 'root', '', 'info_bd');
    if($mysql == false){
        echo mysqli_connect_error();
        exit();
    }

    $result = $mysql->query("SELECT * FROM user WHERE login = '$login'");
    $user = $result->fetch_assoc();
    if(count($user) != 0){
        $_COOKIE['answ'] = '0';
        header('Location: /index_dubl/index_dubl_s.php');
    }


    if($_COOKIE['answ'] == '1'){
        $mysql->query("INSERT INTO user (name, password, login) VALUES('$name', '$password', '$login')");
        header('Location: /main/menu.php');
        setcookie('user', $login, time() + 3600, "/");
    }

    $mysql->close();

?>