<?php
    $login = filter_var(trim($_POST['login']), FILTER_SANITIZE_STRING);
    $password = filter_var(trim($_POST['pass']), FILTER_SANITIZE_STRING);

    $mysql = new mysqli('127.0.0.1', 'root', '', 'info_bd');
    if($mysql == false){
        echo mysqli_connect_error();
        exit();
    }

    $result = $mysql->query("SELECT * FROM user WHERE login = '$login' AND password = '$password'");
    $user = $result->fetch_assoc();
    if(count($user) == 0){
        echo "Пользователь не найден";
        header('Location: ../index_dubl/index_dubl_l.php');
    }
    else {
        setcookie('user', $user['login'], time() + 3600, "/");
        setcookie('bird', 'img/bird.png', time() + 3600, "/");
        setcookie('point', '1', time() + 3600, "/");

        header('Location: /main/menu.php');
    }

    $mysql->close();

?>